/*
 * main.cpp
 *
 *  Created on: Mar 2, 2015
 *      Author: nyalcinb
 */

#pragma once
#include <stdio.h>
#include <opencv2/opencv.hpp>

#include <cstring>
#include <map>
#include <string>
#include <vector>
#include <dirent.h>
#include <sys/types.h>
#include "../include/geometric_normalization.h"
#include "../include/ICPR2012CellDataset.h"

using namespace std;

using namespace cv;


int main()
{
	string db_path = "DB/ICPR2012/";

	//crop_and_rotate();
	//add_normalized_SNPHEP2();
	//add_normalized_ICPR2014();
	//apply_transformations();
	//add_SNPHEP2();
	add_ICPR2014();
	//ICPR2012 contest_data;
    //contest_data.normalizeGeometryPopColor();
	//contest_data.three_different_channel();
	//transform_and_add_data();
	//contest_data.save_original_data();
	//contest_data.doit();

	//ICPR2012_Hep2_Data_File();
	//populate_train_data_by_transformations_create_lmbd(db_path);

	return 0;
}
