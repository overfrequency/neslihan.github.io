/*
 * ICPR2012CellDataset.cpp
 *
 *  Created on: Mar 10, 2015
 *      Author: nyalcinb
 */
#pragma once
#include "../include/ICPR2012CellDataset.h"
#include "../include/geometric_normalization.h"
#include "../include/utility.h"
#include <fstream>
#include <iostream>


ICPR2012::ICPR2012()
{

}


void ICPR2012::get_image_csv_vector()
{
	img_csv_vec.clear();
	//num_of_images=2;


	for (int i = 1 ; i < num_of_images+1 ; i++)
	{

		std::string img_str = std::to_string(i);
		if (img_str.size()==1)
			img_str = "0"+img_str;
		std::string csv_name = master_folder_str + "Main_Dataset//Images//"+img_str+"//"+img_str+".csv";
		cout<<"reading csv : \n"<<csv_name<<endl;

		std::ifstream input_file(csv_name);
		std::string current_line;


		cv::Mat full_csv;
		int countline =0;
		while (getline(input_file, current_line,'\r'))
		{
			countline++;

			std::vector<int> values;
			// get current line
			stringstream liness(current_line);
			//			if(i ==25)
			//				cout<<current_line<<endl;

			string single_value;

			for (int k = 0 ; k<10 ; k++)
			{
				getline(liness,single_value,';');
				values.push_back(atoi(single_value.c_str()));
			}
			cv::Mat row_csv= cv::Mat(values);
			row_csv = row_csv.reshape(0,1);
			full_csv.push_back(row_csv);
		}
		if (countline<2)
		{
			full_csv.release();
			input_file.close();
			input_file.open(csv_name);
			while (getline(input_file, current_line,'\n'))
			{

				std::vector<int> values;
				// get current line
				stringstream liness(current_line);

				string single_value;

				for (int k = 0 ; k<10 ; k++)
				{
					getline(liness,single_value,';');
					values.push_back(atoi(single_value.c_str()));
				}
				cv::Mat row_csv= cv::Mat(values);
				row_csv = row_csv.reshape(0,1);
				full_csv.push_back(row_csv);
			}
		}

		img_csv_vec.push_back(full_csv);
		//		if(i ==25)
		//		cout<<full_csv<<endl;
	}

}




void ICPR2012::get_contest_cell_csv_mat(void)
{
	std::string csv_name = master_folder_str + "//ICPR2012_Cells_Classification_Contest//cells.csv";
	CvMLData mlData;
	mlData.set_delimiter(';');
	mlData.read_csv(csv_name.c_str());
	//get values
	const CvMat* tmp = mlData.get_values();
	cv::Mat csv_mat(tmp, true);
	csv_mat.copyTo(cell_csv_mat);

	std::map< std::string, int>  tmp_map;
	//map cell labels with csv values
	tmp_map = mlData.get_class_labels_map();
	//	cout<<tmp_map["homogeneous"]<<endl;
	//	cout<<tmp_map["coarse_speckled"]<<endl;
	//	cout<<tmp_map["fine_speckled"]<<endl;
	//	cout<<tmp_map["nucleolar"]<<endl;
	//	cout<<tmp_map["centromere"]<<endl;


	cell_map.insert(std::make_pair(tmp_map["homogeneous"],0));
	cell_map.insert(std::make_pair(tmp_map["coarse_speckled"],1));
	cell_map.insert(std::make_pair(tmp_map["fine_speckled"],2));
	cell_map.insert(std::make_pair(tmp_map["nucleolar"],3));
	cell_map.insert(std::make_pair(tmp_map["centromere"],4));
	cell_map.insert(std::make_pair(tmp_map["cytoplasmatic"],5));

	train_set_value=tmp_map["training"];
	test_set_value=tmp_map["test"];



}

void ICPR2012::read_contest_cell_csv_file( cv::Mat &dst, std::map<std::string,int> &map)
{
	std::string csv_name = master_folder_str + "ICPR2012_Cells_Classification_Contest//cells.csv";
	CvMLData mlData;
	mlData.set_delimiter(';');
	mlData.read_csv(csv_name.c_str());
	//map cell labels with csv values
	map = mlData.get_class_labels_map();
	//get values
	const CvMat* tmp = mlData.get_values();
	cv::Mat csv_mat(tmp, true);
	csv_mat.copyTo(dst);
}

void ICPR2012::read_csv_file_of_image(const int img_idx, cv::Mat &dst,std::map<std::string,int> &map)
{
	std::string img_str = std::to_string(img_idx);
	if (img_str.size()==1)
		img_str = "0"+img_str;
	std::string csv_name = master_folder_str + "Main_Dataset//Images//"+img_str+"//"+img_str+".csv";

	CvMLData mlData;
	mlData.set_delimiter(';');
	mlData.read_csv(csv_name.c_str());
	map = mlData.get_class_labels_map();
	const CvMat* tmp = mlData.get_values();
	cv::Mat csv_mat(tmp, true);
	csv_mat.copyTo(dst);
}

//if channel id == -1, then do not alter chanell, else select one of the channels given with  0=B, 1=G, 2 =R, opencv format
void ICPR2012::read_image_mask_from_index(const int img_idx,cv::Mat &img, int channel_id,bool enhance, cv::Mat &mask)
{
	std::string img_str = std::to_string(img_idx);
	if (img_str.size()==1)
		img_str = "0"+img_str;
	std::string img_name = master_folder_str + "Main_Dataset//Images//"+img_str+"//"+img_str+".bmp";
	img = cv::imread(img_name,1);

	std::vector<cv::Mat> bgrMat;
	if (channel_id!= -1)
	{
		split(img,bgrMat);
		bgrMat[channel_id].copyTo(img);
	}
	if (enhance)
		enhanceContrast(img,img);
	//cv::imshow("image",img);waitKey();

	img_name = master_folder_str + "Main_Dataset//Images//"+img_str+"//"+img_str+"_mask.bmp";
	mask = cv::imread(img_name,0);
}


void ICPR2012::doit()
{

	get_contest_cell_csv_mat();
	get_image_csv_vector();

	std::string	file_name;
	std::string outputFolder = "../../ICPR2012/";

	file_name=outputFolder+"/test_file_list.txt";
	std::ofstream outTest(file_name);
	file_name=outputFolder+"/train_file_list.txt";
	std::ofstream outTrain(file_name);


	//start from the second row
	cv::Mat img,mask, patch, patch_mask;
	cv::Mat img_csv;

	//	cv::Point2f srcTri[3];
	//	cv::Point2f dstTri[3];

	int set ; //train=0 , test=1

	//cout<<img_csv_vec.size()<<endl;

	for (int i = 1 ; i < cell_csv_mat.rows ; i++)
	{
		cout<<"img count: "<<i<<endl;
		//find image id and cell id column number (starting from 1)
		int img_idx = cell_csv_mat.ptr<float>( i , img_idx_col-1)[0];
		int cell_idx = cell_csv_mat.ptr<float>( i , cell_idx_col-1)[0];
		//read image and mask
		//cout<<img_idx<<endl;
		//cout<<cell_idx<<endl;
		//img_csv_vec[img_idx-1].copyTo(img_csv);
		img_csv = img_csv_vec[img_idx-1];
		//cout<<img_csv<<endl;
		//cout<<img_csv.cols<<"  , "<<img_csv.rows<<endl;
		read_image_mask_from_index(img_idx,img,1,false,mask);

		//cout<<img_csv<<endl;
		//find cell location in the bigger image and mask
		int maxX = img_csv.ptr<int>(cell_idx, maxX_col)[0];
		int maxY = img_csv.ptr<int>(cell_idx, maxY_col)[0];
		int minX = img_csv.ptr<int>(cell_idx, minX_col)[0];
		int minY = img_csv.ptr<int>(cell_idx, minY_col)[0];
		img.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch);
		mask.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch_mask);
		//mask images have errors
		std::string set_str = (cell_csv_mat.ptr<float>( i , 1)[0] == train_set_value) ? "training/" : "test/";
		std::string contest_id = std::to_string(int (cell_csv_mat.ptr<float>( i , 0)[0]));
		if (contest_id.size()==1)
			contest_id = "00"+contest_id;
		else if (contest_id.size()==2)
			contest_id = "0"+contest_id;

		std::string mask_path = master_folder_str + "ICPR2012_Cells_Classification_Contest//"
				+set_str+contest_id+"_mask.png";

		patch_mask =cv::imread(mask_path,0);
		//fir ellipse
		cv::RotatedRect min_ellipse;
		fit_ellipse_to_mask(patch_mask,min_ellipse);

		cv::Point2f big_center = min_ellipse.center + cv::Point2f(minX,minY);
		cv::RotatedRect rect(big_center,min_ellipse.size, min_ellipse.angle);

		cv::Mat normalized_cell;
		extract_rotated_patch(img,rect,normalized_cell);

		cv::cvtColor(patch_mask,patch_mask,CV_GRAY2BGR);
		cv::ellipse( patch_mask, min_ellipse,cv::Scalar(100,50,150), 2, 8 );
		cv::imshow("patch",patch);cv::waitKey(10);
		//cv::cvtColor(normalized_cell,normalized_cell,CV_BGR2GRAY);
		enhanceContrast(normalized_cell,normalized_cell);
		cv::imshow("normalizeied_cell",normalized_cell);cv::waitKey(10);
		cv::imshow("patch_mask",patch_mask);cv::waitKey(10);




		cv::resize(normalized_cell,normalized_cell,final_size);

		//check train or test flag
		if (cell_csv_mat.ptr<float>( i , 1)[0] == train_set_value)
		{
			int contest_id = cell_csv_mat.ptr<float>( i , 0)[0];
			set=0;
			file_name=outputFolder+"/train/"+std::to_string(contest_id)+".png";
			cv::imwrite(file_name,normalized_cell);
			outTrain<<std::to_string(contest_id)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
		}
		else
		{
			int contest_id = cell_csv_mat.ptr<float>( i , 0)[0];
			set =1;
			file_name=outputFolder+"/test/"+std::to_string(contest_id)+".png";
			cv::imwrite(file_name,normalized_cell);
			outTest<<std::to_string(contest_id)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
		}


		bool write_out = false;
		if(write_out)
		{
			cout<< "train:0 - test:1 = "<<set<<endl;
			cout<< "image idx == "<<img_idx<<endl;
			cout<<"cell_idx = "<< cell_idx<<endl;
			cout<< "id = "<<cell_csv_mat.ptr<float>( i , 0)[0]<<endl;
			cout<< "class label = "<< cell_class[cell_map[cell_class_col-1]]<<endl;

			cout<<" minX = "<<minX<<endl;
			cout<<" minY = "<<minY<<endl;
			cout<<" maxX = "<<maxX<<endl;
			cout<<" maxY = "<<maxY<<endl;
			cv::waitKey();
		}


		//		int key = cv::waitKey()%256;
		//		if (key == 27 )
		//		{
		//			cv::imwrite("patch.png",patch);
		//			cv::imwrite("normalized.png",normalized_cell);
		//			cv::imwrite("mask.png",patch_mask);
		//		}

	}


}

void ICPR2012::save_original_data()
{

	get_contest_cell_csv_mat();
	get_image_csv_vector();

	std::string	file_name;
	std::string outputFolder = "../../ICPR2012/";

	file_name=outputFolder+"/test_file_list.txt";
	std::ofstream outTest(file_name);
	file_name=outputFolder+"/train_file_list.txt";
	std::ofstream outTrain(file_name);


	//start from the second row
	cv::Mat img,mask, patch, patch_mask;
	cv::Mat img_csv;
	int img_count=1;

	RNG rng( getTickCount() );
	int rnd;

	for (int i = 1 ; i < cell_csv_mat.rows ; i++)
	{
		cout<<"img count: "<<i<<endl;
		//find image id and cell id column number (starting from 1)
		int img_idx = cell_csv_mat.ptr<float>( i , img_idx_col-1)[0];
		int cell_idx = cell_csv_mat.ptr<float>( i , cell_idx_col-1)[0];
		//read image and mask
		//cout<<img_idx<<endl;
		//cout<<cell_idx<<endl;
		//img_csv_vec[img_idx-1].copyTo(img_csv);
		img_csv = img_csv_vec[img_idx-1];
		//cout<<img_csv<<endl;
		//cout<<img_csv.cols<<"  , "<<img_csv.rows<<endl;
		read_image_mask_from_index(img_idx,img,1,false,mask);

		//cout<<img_csv<<endl;
		//find cell location in the bigger image and mask
		int maxX = img_csv.ptr<int>(cell_idx, maxX_col)[0];
		int maxY = img_csv.ptr<int>(cell_idx, maxY_col)[0];
		int minX = img_csv.ptr<int>(cell_idx, minX_col)[0];
		int minY = img_csv.ptr<int>(cell_idx, minY_col)[0];
		img.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch);
		mask.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch_mask);
		//mask images have errors
		std::string set_str = (cell_csv_mat.ptr<float>( i , 1)[0] == train_set_value) ? "training/" : "test/";
		std::string contest_id = std::to_string(int (cell_csv_mat.ptr<float>( i , 0)[0]));
		if (contest_id.size()==1)
			contest_id = "00"+contest_id;
		else if (contest_id.size()==2)
			contest_id = "0"+contest_id;

		std::string mask_path = master_folder_str + "ICPR2012_Cells_Classification_Contest//"
				+set_str+contest_id+"_mask.png";

		patch_mask =cv::imread(mask_path,0);



		//for moving some test images to train set
		if (cell_csv_mat.ptr<float>( i , 1)[0] == test_set_value)
		{
			rnd =rng.uniform(0, 2);
			cout<<rnd<<endl;
		}
		else
			rnd =0;


		//check train or test flag
		if (cell_csv_mat.ptr<float>( i , 1)[0] == train_set_value)
		//if(rnd==0)
		{
			//save original cropped from big image
			cv::resize(patch,patch,final_size);
			cv::imshow("patch",patch);cv::waitKey(10);
			//cv::imshow("patch_mask",patch_mask);cv::waitKey(10);

			int contest_id = cell_csv_mat.ptr<float>( i , 0)[0];
			//file_name=outputFolder+"/train/"+std::to_string(contest_id)+".png";
			enhanceContrast(patch,patch);
			file_name=outputFolder+"/train/"+std::to_string(img_count)+".png";
			cv::imwrite(file_name,patch);
			//outTrain<<std::to_string(contest_id)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
			outTrain<<std::to_string(img_count)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
			img_count++;


//			//save enhanced patch
//			enhanceContrast(patch,patch);
//			cv::resize(patch,patch,final_size);
//			file_name=outputFolder+"/train/"+std::to_string(img_count)+".png";
//			cv::imwrite(file_name,patch);
//			outTrain<<std::to_string(img_count)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
//			img_count++;
//			cv::imshow("patch",patch);cv::waitKey(10);

			//save cropped from contrast enhanced big image
			Mat m_img;
			img.copyTo(m_img);
			enhanceContrast(m_img,m_img);
			m_img.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch);
			cv::resize(patch,patch,final_size);
			file_name=outputFolder+"/train/"+std::to_string(img_count)+".png";
			cv::imwrite(file_name,patch);
			outTrain<<std::to_string(img_count)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
			img_count++;
			cv::imshow("patch",patch);cv::waitKey(10);

		
		}
		else
		{
			Mat m_img;
			img.copyTo(m_img);
			//enhanceContrast(m_img,m_img);
			m_img.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch);
			enhanceContrast(patch,patch);
			cv::resize(patch,patch,final_size);
			cv::imshow("patch",patch);cv::waitKey(10);
			//cv::imshow("patch_mask",patch_mask);cv::waitKey(10);

			int contest_id = cell_csv_mat.ptr<float>( i , 0)[0];
			file_name=outputFolder+"/test/"+std::to_string(contest_id)+".png";
			cv::imwrite(file_name,patch);
			outTest<<std::to_string(contest_id)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
		}




	}


}


void transform_and_add_data()
{
	ICPR2012 data;
	data.get_contest_cell_csv_mat();
	data.get_image_csv_vector();

	std::string	file_name;
	std::string outputFolder = "../../ICPR2012/";

	file_name=outputFolder+"/test_file_list.txt";
	std::ofstream outTest(file_name);
	file_name=outputFolder+"/train_file_list.txt";
	std::ofstream outTrain(file_name);

	//start from the second row
	cv::Mat img,mask, patch, patch_mask;
	cv::Mat img_csv;

	int count =0;

	for (int i = 1 ; i < data.cell_csv_mat.rows ; i++)
	{
		cout<<"img count: "<<i<<endl;
		//find image id and cell id column number (starting from 1)
		int img_idx = data.cell_csv_mat.ptr<float>( i , data.img_idx_col-1)[0];
		int cell_idx = data.cell_csv_mat.ptr<float>( i , data.cell_idx_col-1)[0];
		img_csv = data.img_csv_vec[img_idx-1];
		data.read_image_mask_from_index(img_idx,img,1,false,mask);

		//cout<<img_csv<<endl;
		//find cell location in the bigger image and mask
		int maxX = img_csv.ptr<int>(cell_idx, data.maxX_col)[0];
		int maxY = img_csv.ptr<int>(cell_idx, data.maxY_col)[0];
		int minX = img_csv.ptr<int>(cell_idx, data.minX_col)[0];
		int minY = img_csv.ptr<int>(cell_idx, data.minY_col)[0];
		//img.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch);
		//mask.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch_mask);
		//enhanceContrast(patch,patch);
		//imwrite("enhanced.png", patch);
		//imwrite("mask.png", patch_mask); waitKey();

		//mask images have errors (ie in 8.bmp for cell 32), therefore use cropped masks
		std::string set_str = (data.cell_csv_mat.ptr<float>( i , 1)[0] == data.train_set_value) ? "training/" : "test/";
		std::string contest_id = std::to_string(int (data.cell_csv_mat.ptr<float>( i , 0)[0]));
		if (contest_id.size()==1)
			contest_id = "00"+contest_id;
		else if (contest_id.size()==2)
			contest_id = "0"+contest_id;
		std::string mask_path = data.master_folder_str + "ICPR2012_Cells_Classification_Contest//"
				+set_str+contest_id+"_mask.png";
		patch_mask =cv::imread(mask_path,0);

		//apply transformations
		vector<cv::Mat> transformed_patches;
		cv::Point minp(minX,minY), maxp(maxX,maxY);
		cv::Mat vert;
		vert.push_back(minp);
		vert.push_back(maxp);
		cv::Rect crop = cv::boundingRect(vert);

		if (data.cell_csv_mat.ptr<float>( i , 1)[0] == data.test_set_value) //if test image
		{

			apply_rotation_to_masked_patch(img,crop,patch_mask,false,data.final_size,transformed_patches);
			//apply_rotation_to_patch2(img,crop,patch_mask,false,transformed_patches);
			Mat normalized_cell = transformed_patches[0];
			enhanceContrast(normalized_cell,normalized_cell);
			shapeIndex(normalized_cell,normalized_cell);
			//	cv::resize(normalized_cell,normalized_cell,data.final_size);
			cv::imshow("normalized_cell",normalized_cell);cv::waitKey(10);

			file_name=outputFolder+"/test/"+std::to_string(count)+".png";
			cv::imwrite(file_name,normalized_cell);
			outTest<<std::to_string(count)+".png"<<" "<< data.cell_map[int(data.cell_csv_mat.ptr<float>( i,data.cell_class_col-1 )[0])]<<endl;
			count++;

		}
		else
		{
			apply_rotation_to_masked_patch(img,crop,patch_mask,false,data.final_size,transformed_patches);
			//apply_rotation_to_patch2(img,crop,patch_mask,true,transformed_patches);
			//resize and save images including the original one (i.e. rotation at 0 angle)
			for (int k = 0 ; k < transformed_patches.size(); k++)
			{
				//	enhanceContrast(transformed_patches[k],transformed_patches[k]);
				shapeIndex(transformed_patches[k],transformed_patches[k]);
				//	cv::resize(transformed_patches[k],transformed_patches[k],data.final_size);
				cv::imshow("tranformed",transformed_patches[k]); waitKey(10);

				file_name=outputFolder+"/train/"+std::to_string(count)+".png";
				cv::imwrite(file_name,transformed_patches[k]);
				outTrain<<std::to_string(count)+".png"<<" "<< data.cell_map[int(data.cell_csv_mat.ptr<float>( i,data.cell_class_col-1 )[0])]<<endl;
				count++;
			}
		}
	}
}


void add_ICPR2014()
{
	string icpr2014master= "../ICPR2014/ICIP2013_training_1.0/";

	string csv_str = icpr2014master+"gt_training.csv";
	ifstream train_csv (csv_str);

	string
	train_line,
	id,
	class_str;

	std::vector<std::string> cell_class= {"Homogeneous","coarse_speckled","fine_speckled","Nucleolar","Centromere","cytoplasmatic","Speckled","NuMem","Golgi"};

	string icpr2012 ="../ICPR2012/";
	std::ofstream fs(icpr2012+"train_file_list.txt", std::ofstream::out | std::ofstream::app);

	getline(train_csv, train_line) ;
	cout<<train_line<<endl;

	//	int line_num = 1;
	//	while (line_num <3000) {
	//		getline(train_csv, train_line);
	//		line_num++;
	//	}

	int img_num=1;
	int add_num = 3248; //2163;//3969;

	while (getline(train_csv, train_line)) {
		// get current line
		stringstream liness(train_line);
		// split line
		getline(liness, id,',');
		getline(liness, class_str,'\r');
		cout<<id<<", ";
		cout<<class_str<<endl;

		while(id.size()<5)
			id = "0"+id;

		int index = std::find(cell_class.begin(),cell_class.end(),class_str) - cell_class.begin();
		if (index >=6){
			continue;
		}
		else{

			//fs<<app_id+".png"<<" "<<index<<endl;

			Mat img = imread(icpr2014master+"train/"+id+".png",0);
			//enhanceContrast(img,img);
			cv::resize(img,img,cv::Size(64,64));



			enhanceContrast(img,img);
			string app_str =  std::to_string(img_num+add_num) +".png";
			fs<<app_str<<" "<<index<<endl;
			cout<<app_str<<" "<<index<<endl;
			string file_name=icpr2012+"/train/"+app_str;
			cv::imwrite(file_name,img);
			img_num++;
			cv::imshow("normalized_cell",img);cv::waitKey(10);


//			enhanceContrast(img,img);
//			app_str =  std::to_string(img_num+add_num) +".png";
//			fs<<app_str<<" "<<index<<endl;
//			cout<<app_str<<" "<<index<<endl;
//			file_name=icpr2012+"/train/"+app_str;
//			cv::imwrite(file_name,img);
//			img_num++;
//			cv::imshow("normalized_cell",img);cv::waitKey(10);
		}

	}

}



void add_SNPHEP2()
{
	string snphep_master="../SNPHEp-2/";
	//string snphep_master= "/run/user/1000/gvfs/smb-share:server=samba.ee,share=r-biovis/library/databases/SNPHEp-2/";

	string csv_str = snphep_master+"split_information/test.txt";
	ifstream test_csv (csv_str);

	string
	train_line,
	id,
	class_str;

	string icpr2012 ="../ICPR2012/";
	std::ofstream fs(icpr2012+"train_file_list.txt", std::ofstream::out | std::ofstream::app);

	int class_id=-1;
	int img_num=1;

	int add_num = 1442;//721;//2163;
	while (getline(test_csv, train_line)) {

		stringstream liness(train_line);
		// split line
		getline(liness, id,',');
		getline(liness, class_str,'\r');

		class_id = std::atoi(class_str.c_str())-1;

		while(id.size()<3)
			id = "0"+id;

		string img_str = id ;

		Mat img = imread(snphep_master+"cell_level/test/"+img_str+".png",0);
		//imshow("img",img); waitKey(10);
		Mat img_mask =  imread(snphep_master+"cell_level/test/"+img_str+"_Mask.png",0);


		string app_str =  std::to_string(img_num+add_num) +".png";
		cout<<app_str<<" "<<class_id<<endl;
		fs<<app_str<<" "<<class_id<<endl;

		std::string outputFolder = "../../ICPR2012/";
		string file_name=outputFolder+"/train/"+app_str;

		enhanceContrast(img,img);
		cv::resize(img,img,cv::Size(64,64));
		cv::imshow("normalized_cell",img);cv::waitKey(10);
		cv::imwrite(file_name,img);
		img_num++;

//		enhanceContrast(img,img);
//		app_str =  std::to_string(img_num+add_num) +".png";
//		cout<<app_str<<" "<<class_id<<endl;
//		fs<<app_str<<" "<<class_id<<endl;
//		file_name=outputFolder+"/train/"+app_str;
//		cv::imwrite(file_name,img);
//		img_num++;
	}


	csv_str = snphep_master+"split_information/train.txt";
	ifstream train_csv (csv_str);

	while (getline(train_csv, train_line)) {

		stringstream liness(train_line);
		// split line
		getline(liness, id,',');
		getline(liness, class_str,'\r');

		class_id = std::atoi(class_str.c_str())-1;

		while(id.size()<3)
			id = "0"+id;

		string img_str = id ;

		Mat img = imread(snphep_master+"cell_level/train/"+img_str+".png",0);
		//imshow("img",img); waitKey(10);
		Mat img_mask =  imread(snphep_master+"cell_level/train/"+img_str+"_Mask.png",0);



		string app_str =  std::to_string(img_num+add_num) +".png";
		cout<<app_str<<" "<<class_id<<endl;
		fs<<app_str<<" "<<class_id<<endl;

		std::string outputFolder = "../../ICPR2012/";

		//save original
		enhanceContrast(img,img);
		string file_name=outputFolder+"/train/"+app_str;
		cv::resize(img,img,cv::Size(64,64));
		cv::imshow("normalized_cell",img);cv::waitKey(10);
		cv::imwrite(file_name,img);
		img_num++;


//		//save enhanced
//		enhanceContrast(img,img);
//		app_str =  std::to_string(img_num+add_num) +".png";
//		cout<<app_str<<" "<<class_id<<endl;
//		fs<<app_str<<" "<<class_id<<endl;
//		file_name=outputFolder+"/train/"+app_str;
//		cv::imwrite(file_name,img);
//		img_num++;
	}


}



void apply_transformations (){
	//apply rotations, zoom in-out, shift to resized data
	//inpaint image borders

	std::string input_folder = "../../ICPR2012/train/";
	std::string output_folder = "../../ICPR2012/pop_train/";


	std::vector <std::string>  image_list= read_directory(input_folder);
	string icpr2012 ="../ICPR2012/";
	std::ofstream fs(icpr2012+"pop_train_file_list.txt", std::ofstream::out | std::ofstream::app);

	vector <Mat> images;
	int img_num=0;


	string csv_str = icpr2012+"train_file_list.txt";
	ifstream train_csv (csv_str);

	string
	train_line,
	id,
	class_str;
	while (getline(train_csv, train_line)) {
		// get current line
		stringstream liness(train_line);
		// split line
		getline(liness, id,' ');
		getline(liness, class_str,'\r');
		cout<<id<<", ";
		cout<<class_str<<endl;

		Mat img = imread(input_folder+id, 0);
		imshow("img",img);
		waitKey(10);


		//rotate (scale by taking largest rectangle)
		//and mirror rotated
		for (int angle = 0 ; angle <360 ; angle+=18)
		{
			Mat rotated;
			rotate(img,angle,Point2f(),rotated);
			cv::Size largest_rect = largest_rotated_rect(img.rows,img.cols,degree_to_radian(angle));
			Mat crop = crop_around_center(rotated,largest_rect.height,largest_rect.width);

			cv::resize(crop,crop,cv::Size(64,64));
			imshow("crop",crop); waitKey(10);

			string app_str =  std::to_string(img_num) +".png";
			cout<<app_str<<" "<<class_str<<endl;
			fs<<app_str<<" "<<class_str<<endl;
			string file_name=output_folder+app_str;
			cv::imwrite(file_name,crop);
			img_num++;


			//mirror
			flip(crop,crop,1);
			app_str =  std::to_string(img_num) +".png";
			cout<<app_str<<" "<<class_str<<endl;
			fs<<app_str<<" "<<class_str<<endl;
			file_name=output_folder+app_str;
			cv::imwrite(file_name,crop);
			imshow("crop",crop); waitKey(10);
			img_num++;

		}





	}





}


void ICPR2012::normalizeGeometryPopColor()
{

	get_contest_cell_csv_mat();
	get_image_csv_vector();

	std::string	file_name;
	std::string outputFolder = "../../ICPR2012/";

	file_name=outputFolder+"/test_file_list.txt";
	std::ofstream outTest(file_name);
	file_name=outputFolder+"/train_file_list.txt";
	std::ofstream outTrain(file_name);


	//start from the second row
	cv::Mat img,mask, patch, patch_mask;
	cv::Mat img_csv;
	int img_count=1;

	RNG rng( getTickCount() );
	int rnd;

	cv::Mat imgcopy;


	for (int i = 1 ; i < cell_csv_mat.rows ; i++)
	{
		cout<<"img count: "<<i<<endl;
		//find image id and cell id column number (starting from 1)
		int img_idx = cell_csv_mat.ptr<float>( i , img_idx_col-1)[0];
		int cell_idx = cell_csv_mat.ptr<float>( i , cell_idx_col-1)[0];
		img_csv = img_csv_vec[img_idx-1];
		read_image_mask_from_index(img_idx,img,1,false,mask);
		img.copyTo(imgcopy);

		//cout<<img_csv<<endl;
		//find cell location in the bigger image and mask
		int maxX = img_csv.ptr<int>(cell_idx, maxX_col)[0];
		int maxY = img_csv.ptr<int>(cell_idx, maxY_col)[0];
		int minX = img_csv.ptr<int>(cell_idx, minX_col)[0];
		int minY = img_csv.ptr<int>(cell_idx, minY_col)[0];
		img.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch);
		mask.rowRange(minY,maxY).colRange(minX,maxX).copyTo(patch_mask);
		//mask images have errors
		std::string set_str = (cell_csv_mat.ptr<float>( i , 1)[0] == train_set_value) ? "training/" : "test/";
		std::string contest_id = std::to_string(int (cell_csv_mat.ptr<float>( i , 0)[0]));
		if (contest_id.size()==1)
			contest_id = "00"+contest_id;
		else if (contest_id.size()==2)
			contest_id = "0"+contest_id;

		std::string mask_path = master_folder_str + "ICPR2012_Cells_Classification_Contest//"
				+set_str+contest_id+"_mask.png";

		patch_mask =cv::imread(mask_path,0);



		//fir ellipse
		cv::RotatedRect min_ellipse;
		fit_ellipse_to_mask(patch_mask,min_ellipse);

		cv::Point2f big_center = min_ellipse.center + cv::Point2f(minX,minY);
		cv::RotatedRect rect(big_center,min_ellipse.size, min_ellipse.angle);

		cv::Mat normalized_cell;




		//check train or test flag
		if (cell_csv_mat.ptr<float>( i , 1)[0] == train_set_value)
		{

			mask.setTo(Scalar(0));
			//patch_mask.copyTo(mask.rowRange(minY,maxY).colRange(minX,maxX));
			//imgcopy.setTo(Scalar(0),~mask);
			//imshow("mask",mask);

			//save original cropped from big image
			cv::Mat normalized_cell;
			extract_rotated_patch(img,rect,normalized_cell);
			cv::resize(normalized_cell,normalized_cell,final_size);
			cv::imshow("patch",normalized_cell);
			//cv::waitKey(10);


			int contest_id = cell_csv_mat.ptr<float>( i , 0)[0];
			file_name=outputFolder+"/train/"+std::to_string(img_count)+".png";
			cv::imwrite(file_name,normalized_cell);
			//outTrain<<std::to_string(contest_id)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
			outTrain<<std::to_string(img_count)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
			img_count++;


			//save enhanced patch
			enhanceContrast(normalized_cell,normalized_cell);
			file_name=outputFolder+"/train/"+std::to_string(img_count)+".png";
			cv::imwrite(file_name,normalized_cell);
			outTrain<<std::to_string(img_count)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
			img_count++;
			//cv::imshow("patch",normalized_cell);cv::waitKey(10);

			//save cropped from contrast enhanced big image
			Mat m_img;
			img.copyTo(m_img);
			enhanceContrast(m_img,m_img);
			//m_img.setTo(Scalar(0),~mask);

			extract_rotated_patch(m_img,rect,normalized_cell);
			cv::resize(normalized_cell,normalized_cell,final_size);
			cv::imshow("patch",normalized_cell);cv::waitKey(10);
			file_name=outputFolder+"/train/"+std::to_string(img_count)+".png";
			cv::imwrite(file_name,normalized_cell);
			outTrain<<std::to_string(img_count)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
			img_count++;


		}
		else
		{

			Mat m_img;
			img.copyTo(m_img);
			enhanceContrast(m_img,m_img);

			//m_img.setTo(Scalar(0),~mask);

			extract_rotated_patch(m_img,rect,patch);
			cv::resize(patch,patch,final_size);
			cv::imshow("patch",patch);cv::waitKey(10);


			int contest_id = cell_csv_mat.ptr<float>( i , 0)[0];
			file_name=outputFolder+"/test/"+std::to_string(contest_id)+".png";
			cv::imwrite(file_name,patch);
			outTest<<std::to_string(contest_id)+".png"<<" "<< cell_map[int(cell_csv_mat.ptr<float>( i,cell_class_col-1 )[0])]<<endl;
		}




	}


}



void add_normalized_ICPR2014()
{
	string icpr2014master= "../ICPR2014/ICIP2013_training_1.0/";

	string csv_str = icpr2014master+"gt_training.csv";
	ifstream train_csv (csv_str);

	string
	train_line,
	id,
	class_str;

	std::vector<std::string> cell_class= {"Homogeneous","coarse_speckled","fine_speckled","Nucleolar","Centromere","cytoplasmatic","Speckled","NuMem","Golgi"};

	string icpr2012 ="../ICPR2012/";
	std::ofstream fs(icpr2012+"train_file_list.txt", std::ofstream::out | std::ofstream::app);

	getline(train_csv, train_line) ;
	cout<<train_line<<endl;

	//	int line_num = 1;
	//	while (line_num <3000) {
	//		getline(train_csv, train_line);
	//		line_num++;
	//	}

	int img_num=1;
	int add_num = 2163;//3969;

	while (getline(train_csv, train_line)) {
		// get current line
		stringstream liness(train_line);
		// split line
		getline(liness, id,',');
		getline(liness, class_str,'\r');
		cout<<id<<", ";
		cout<<class_str<<endl;

		while(id.size()<5)
			id = "0"+id;

		int index = std::find(cell_class.begin(),cell_class.end(),class_str) - cell_class.begin();
		if (index >=6){
			continue;
		}
		else{

			//fs<<app_id+".png"<<" "<<index<<endl;

			Mat img = imread(icpr2014master+"train/"+id+".png",0);
			enhanceContrast(img,img);
			//cv::resize(img,img,cv::Size(64,64));

			Mat patch_mask = imread(icpr2014master+"train/"+id+"_Mask.png",0);

			//img.setTo(Scalar(0),~patch_mask);

			//fir ellipse
			cv::RotatedRect min_ellipse;
			fit_ellipse_to_mask(patch_mask,min_ellipse);

			cv::Point2f big_center = min_ellipse.center;
			cv::RotatedRect rect(big_center,min_ellipse.size, min_ellipse.angle);

			cv::Mat normalized_cell;

			extract_rotated_patch(img,rect,normalized_cell);
			cv::resize(normalized_cell,normalized_cell,cv::Size(64,64));

			normalized_cell.copyTo(img);

			string app_str =  std::to_string(img_num+add_num) +".png";
			fs<<app_str<<" "<<index<<endl;
			cout<<app_str<<" "<<index<<endl;
			string file_name=icpr2012+"/train/"+app_str;
			cv::imwrite(file_name,img);
			img_num++;
			cv::imshow("normalized_cell",img);cv::waitKey(5);


//			enhanceContrast(img,img);
//			app_str =  std::to_string(img_num+add_num) +".png";
//			fs<<app_str<<" "<<index<<endl;
//			cout<<app_str<<" "<<index<<endl;
//			file_name=icpr2012+"/train/"+app_str;
//			cv::imwrite(file_name,img);
//			img_num++;
//			cv::imshow("normalized_cell",img);cv::waitKey(10);
		}

	}

}


void add_normalized_SNPHEP2()
{
	string snphep_master="../SNPHEp-2/";
	
	string csv_str = snphep_master+"split_information/test.txt";
	ifstream test_csv (csv_str);

	string
	train_line,
	id,
	class_str;

	string icpr2012 ="../ICPR2012/";
	std::ofstream fs(icpr2012+"train_file_list.txt", std::ofstream::out | std::ofstream::app);

	int class_id=-1;
	int img_num=1;

	int add_num = 2163;
	while (getline(test_csv, train_line)) {

		stringstream liness(train_line);
		// split line
		getline(liness, id,',');
		getline(liness, class_str,'\r');

		class_id = std::atoi(class_str.c_str())-1;

		while(id.size()<3)
			id = "0"+id;

		string img_str = id ;

		Mat img = imread(snphep_master+"cell_level/test/"+img_str+".png",0);
		//imshow("img",img); waitKey(10);
		Mat img_mask =  imread(snphep_master+"cell_level/test/"+img_str+"_Mask.png",0);

		img.setTo(Scalar(0),~img_mask);

		cv::RotatedRect min_ellipse;
		fit_ellipse_to_mask(img_mask,min_ellipse);

		cv::Point2f big_center = min_ellipse.center;
		cv::RotatedRect rect(big_center,min_ellipse.size, min_ellipse.angle);
		cv::Mat normalized_cell;
		extract_rotated_patch(img,rect,normalized_cell);
	    normalized_cell.copyTo(img);


		string app_str =  std::to_string(img_num+add_num) +".png";
		cout<<app_str<<" "<<class_id<<endl;
		fs<<app_str<<" "<<class_id<<endl;

		std::string outputFolder = "../../ICPR2012/";
		string file_name=outputFolder+"/train/"+app_str;

		enhanceContrast(img,img);
		cv::resize(img,img,cv::Size(64,64));
		cv::imshow("normalized_cell",img);cv::waitKey(10);
		cv::imwrite(file_name,img);
		img_num++;

//		enhanceContrast(img,img);
//		app_str =  std::to_string(img_num+add_num) +".png";
//		cout<<app_str<<" "<<class_id<<endl;
//		fs<<app_str<<" "<<class_id<<endl;
//		file_name=outputFolder+"/train/"+app_str;
//		cv::imwrite(file_name,img);
//		img_num++;
	}


	csv_str = snphep_master+"split_information/train.txt";
	ifstream train_csv (csv_str);

	while (getline(train_csv, train_line)) {

		stringstream liness(train_line);
		// split line
		getline(liness, id,',');
		getline(liness, class_str,'\r');

		class_id = std::atoi(class_str.c_str())-1;

		while(id.size()<3)
			id = "0"+id;

		string img_str = id ;

		Mat img = imread(snphep_master+"cell_level/train/"+img_str+".png",0);
		//imshow("img",img); waitKey(10);
		Mat img_mask =  imread(snphep_master+"cell_level/train/"+img_str+"_Mask.png",0);



		cv::RotatedRect min_ellipse;
		fit_ellipse_to_mask(img_mask,min_ellipse);

		cv::Point2f big_center = min_ellipse.center;
		cv::RotatedRect rect(big_center,min_ellipse.size, min_ellipse.angle);
		cv::Mat normalized_cell;
		extract_rotated_patch(img,rect,normalized_cell);
	    normalized_cell.copyTo(img);

		string app_str =  std::to_string(img_num+add_num) +".png";
		cout<<app_str<<" "<<class_id<<endl;
		fs<<app_str<<" "<<class_id<<endl;

		std::string outputFolder = "../../ICPR2012/";

		//save original
		enhanceContrast(img,img);
		string file_name=outputFolder+"/train/"+app_str;
		cv::resize(img,img,cv::Size(64,64));
		cv::imshow("normalized_cell",img);cv::waitKey(10);
		cv::imwrite(file_name,img);
		img_num++;


//		//save enhanced
//		enhanceContrast(img,img);
//		app_str =  std::to_string(img_num+add_num) +".png";
//		cout<<app_str<<" "<<class_id<<endl;
//		fs<<app_str<<" "<<class_id<<endl;
//		file_name=outputFolder+"/train/"+app_str;
//		cv::imwrite(file_name,img);
//		img_num++;
	}


}


void crop_and_rotate()
{
	std::string input_folder = "../../ICPR2012/test30/";
	std::string output_folder = "../../ICPR2012/test/";


	std::vector <std::string>  image_list= read_directory(input_folder);
	string icpr2012 ="../ICPR2012/";
	std::ofstream fs(icpr2012+"test_file_list.txt", std::ofstream::out | std::ofstream::app);

	vector <Mat> images;
	int img_num=0;


	string csv_str = icpr2012+"test_file_list30.txt";
	ifstream train_csv (csv_str);

	string
	train_line,
	id,
	class_str;
	while (getline(train_csv, train_line)) {
		// get current line
		stringstream liness(train_line);
		// split line
		getline(liness, id,' ');
		getline(liness, class_str,'\r');
		cout<<id<<", ";
		cout<<class_str<<endl;

		Mat img = imread(input_folder+id, 0);
		imshow("img",img);
		waitKey(10);


		//rotate (scale by taking largest rectangle)
		//and mirror rotated
		for (int angle = 0 ; angle <360 ; angle+=360)
		{
			Mat rotated;
			rotate(img,angle,Point2f(),rotated);
			Mat crop = crop_around_center(rotated,41,41);

			//cv::resize(crop,crop,cv::Size(64,64));
			imshow("crop",crop); waitKey(5);

			string app_str =  std::to_string(img_num) +".png";
			cout<<app_str<<" "<<class_str<<endl;
			fs<<app_str<<" "<<class_str<<endl;
			string file_name=output_folder+app_str;
			cv::imwrite(file_name,crop);
			img_num++;


//			//mirror
//			flip(crop,crop,1);
//			app_str =  std::to_string(img_num) +".png";
//			cout<<app_str<<" "<<class_str<<endl;
//			fs<<app_str<<" "<<class_str<<endl;
//			file_name=output_folder+app_str;
//			cv::imwrite(file_name,crop);
//			imshow("crop",crop); waitKey(5);
//			img_num++;

		}





	}

}
