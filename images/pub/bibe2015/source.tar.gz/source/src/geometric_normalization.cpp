#pragma once
#include <opencv2/opencv.hpp>
#include <string>
#include "../include/geometric_normalization.h"
#include "../include/utility.h"
#include <fstream> // NOLINT(readability/streams)
#include <sys/stat.h>
using namespace std;
using namespace cv;


//img is a binary mask containing single connected object
void fit_ellipse_to_mask (const Mat &mask, RotatedRect & ellipse)
{
	Mat inp;
	mask.copyTo(inp);
	//make sure mask does not touch to the borders
	inp.rowRange(0,3).setTo(0);
	inp.rowRange(mask.rows-3,mask.rows).setTo(0);
	inp.colRange(0,3).setTo(0);
	inp.colRange(mask.cols-3,mask.cols).setTo(0);

	int largest_area=0;
	int largest_contour_index=0;

	vector<vector<Point>> contours; // Vector for storing contour
	vector<Vec4i> hierarchy;
	findContours( inp,contours,
			hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE,
			Point(0, 0) );

	// iterate through each contour.
	for ( int i = 0; i< contours.size(); i++ ) {
		//  Find the area of contour
		double a=contourArea( contours[i],false);
		if(a>largest_area){
			largest_area=a;
			largest_contour_index=i;
		}
	}

	ellipse= fitEllipse( Mat(contours[largest_contour_index]) );

	//check for errors
	Point2f vertices[4];
	ellipse.points(vertices);
	//   for (int i= 0 ; i<4 ;i++){
	//	   cout<<vertices[i].x  <<", "<< vertices[i].y <<endl;
	//	   CV_Assert(vertices[i].x < 0 || vertices[i].y >0 );
	//   }
}

//rotate image given angle around a specific point center, if it is null then rotate image around its center
void rotate(const cv::Mat& src, const  float angle, const cv::Point2f center, cv::Mat& dst)
{
	cv::Point2f pt;
	if (center ==Point2f())
		pt = Point2f(src.cols>>1, src.rows>>1);
	else
		pt = center;

	cv::Mat r = cv::getRotationMatrix2D(pt, angle, 1.0);
	//cv::warpAffine(src, dst, r, cv::Size(src.cols, src.rows),cv::INTER_LANCZOS4 );
	cv::warpAffine(src, dst, r, cv::Size(),cv::INTER_LANCZOS4 );
}



void draw_rotated_rect(const cv::Mat &img, const cv::RotatedRect  &rect, cv::Mat& drawing)
{
	img.copyTo(drawing);
	Rect brect = rect.boundingRect();
	rectangle(drawing, brect, Scalar(255,0,0));
	Point2f vertices[4];
	rect.points(vertices);
	for (int i = 0; i < 4; i++)
		line(drawing, vertices[i], vertices[(i+1)%4], Scalar(0,255,0));
	circle(drawing,rect.center,2,Scalar(50,210,100),-1);
	//imshow("rect",drawing);waitKey();
}


void apply_rotation_to_masked_patch (const cv::Mat &big_img, const cv::Rect &crop, const cv::Mat &mask,
		const bool rot_flag, const cv::Size sq_size, std::vector<cv::Mat> & transformed_mats )
{
	Mat img;
	big_img.copyTo(img);
	cvtColor(img,img,CV_GRAY2BGR);

	cv::RotatedRect min_ellipse;
	fit_ellipse_to_mask(mask,min_ellipse);
	cv::Point2f big_center = min_ellipse.center + cv::Point2f( crop.tl().x, crop.tl().y ); // cv::Point2f(minX,minY);
	cv::RotatedRect rect(big_center,min_ellipse.size, min_ellipse.angle);

	Mat dst;
	//first normalize region and push it
	extract_rotated_patch(big_img,rect,dst);
	cv::resize(dst,dst,sq_size);

	Mat circle_mask = cv::Mat::zeros(sq_size,CV_8UC1);
	int radius = sq_size.width*0.5;
	Point circle_center = Point(radius,radius);
	circle(circle_mask,circle_center,radius,Scalar(255),-1);
	imshow("mask", circle_mask);waitKey(10);
	dst.setTo(0,~circle_mask);

	transformed_mats.clear();

	if (!rot_flag)
	{
		transformed_mats.push_back(dst);
	}

	if (rot_flag)
	{
		for ( float inc_ang = 0 ; inc_ang <360 ; inc_ang+=18)
		{
			Mat rotated;
			rotate(dst,inc_ang,Point2f(),rotated);
			imshow("rotated",rotated);waitKey(20);
			transformed_mats.push_back(rotated);
		}
	}

}

void rotate_without_crop(const cv::Mat& src, const  float angle, const cv::Point2f pt, cv::Mat& dst)
{
	//adapted from
	//http://stackoverflow.com/questions/22041699/rotate-an-image-without-cropping-in-opencv-in-c
	// get rotation matrix for rotating the image around its center

	cv::Point2f center;
	if (center ==Point2f())
		center = Point2f(src.cols>>1, src.rows>>1);
	else
		center = pt;

	cv::Mat rot = cv::getRotationMatrix2D(center, angle, 1.0);
	// determine bounding rectangle
	cv::Rect bbox = cv::RotatedRect(center,src.size(), angle).boundingRect();
	// adjust transformation matrix
	rot.at<double>(0,2) += bbox.width/2.0 - center.x;
	rot.at<double>(1,2) += bbox.height/2.0 - center.y;
	cv::warpAffine(src, dst, rot, bbox.size());
}


void apply_rotation_to_patch2 (const cv::Mat &big_img, const cv::Rect &crop, const cv::Mat &mask, const bool rot_flag, std::vector<cv::Mat> & transformed_mats )
{
	Mat img;
	big_img.copyTo(img);
	cvtColor(img,img,CV_GRAY2BGR);

	Mat rotated, img_rotated, mask_rotated;
	cv::Point2f big_center = Point2f (mask.cols*0.5, mask.rows*0.5) + cv::Point2f( crop.tl().x, crop.tl().y ); // cv::Point2f(minX,minY);

	float inc_ang_limit ;
	if (rot_flag) inc_ang_limit = 360;
	else inc_ang_limit = 1;
	for ( float inc_ang = 0 ; inc_ang <inc_ang_limit  ; inc_ang+=18)
	{

		circle(img_rotated,big_center,2,Scalar(50,210,100),-1);
		rotate(img,inc_ang,big_center,img_rotated);
		imshow("img_rotated", img_rotated);waitKey();
		rotate_without_crop(mask,inc_ang,Point2f(),mask_rotated);
		imshow("mask_rotated", mask_rotated);waitKey();

		cv::RotatedRect min_ellipse;
		fit_ellipse_to_mask(mask_rotated,min_ellipse);

		cv::cvtColor(mask_rotated,mask_rotated,CV_GRAY2BGR);
		cv::ellipse( mask_rotated, min_ellipse,cv::Scalar(100,50,250), 2, 8 );
		//imwrite("ellipse2.png",mask_rotated);
		cv::imshow("patch",mask_rotated);cv::waitKey(10);

		cv::RotatedRect rect(big_center,min_ellipse.size, min_ellipse.angle);

		Mat dst;
		getRectSubPix(img_rotated, rect.size, rect.center, dst);


		//first normalize region and push it
		//extract_rotated_patch(img_rotated,rect,dst);
		//imwrite("normalized.png",dst);
		imshow("dst", dst);waitKey();
		transformed_mats.push_back(dst);
	}


}

void apply_rotation_to_patch (const cv::Mat &big_img, const cv::Rect &crop, const cv::Mat &mask, const bool rot_flag, std::vector<cv::Mat> & transformed_mats )
{
	Mat img;
	big_img.copyTo(img);
	cvtColor(img,img,CV_GRAY2BGR);

	cv::RotatedRect min_ellipse;
	fit_ellipse_to_mask(mask,min_ellipse);
	cv::Point2f big_center = min_ellipse.center + cv::Point2f( crop.tl().x, crop.tl().y ); // cv::Point2f(minX,minY);
	cv::RotatedRect rect(big_center,min_ellipse.size, min_ellipse.angle);

	Mat dst;
	//first normalize region and push it
	extract_rotated_patch(big_img,rect,dst);
	transformed_mats.push_back(dst);



	double angle, first_angle ;
	first_angle=rect.angle;
	Mat rotated, img_rotated;

	float inc_ang_limit ;
	if (rot_flag) inc_ang_limit = 360;
	else inc_ang_limit = 1;
	for ( float inc_ang = 0 ; inc_ang <inc_ang_limit ; inc_ang+=18)
	{
		rect.angle =first_angle;
		rect.angle -=inc_ang;
		angle = rect.angle;
		rotate(img,inc_ang,rect.center,img_rotated);
		// get the rotation matrix
		Mat M = getRotationMatrix2D(rect.center, angle, 1.0);
		// perform the affine transformation
		cv::warpAffine(img_rotated, rotated, M, Size(), CV_INTER_LANCZOS4);
		// crop
		cv::Rect rect2= rect.boundingRect();
		Point2f ct = (rect2.tl()+rect2.br() ) *0.5;
		Size2f sz (rect2.width,rect2.height);
		getRectSubPix(img_rotated,sz, ct, dst);
		// crop the resulting image
		//getRectSubPix(rotated,rect.size, rect.center, dst);

		//imshow("final",dst);waitKey(10);
		transformed_mats.push_back(dst);
	}


}

//adapted from http://answers.opencv.org/question/497/extract-a-rotatedrect-area/
void extract_rotated_patch(const cv::Mat &src, const cv::RotatedRect &rect, cv::Mat &dst)
{
	// matrices we'll use
	cv::Mat M, rotated;
	// get angle and size from the bounding box
	float angle = rect.angle;
	cv::Size rect_size = rect.size;
	// thanks to http://felix.abecassis.me/2011/10/opencv-rotation-deskewing/
	if (rect.angle < -45.) {
		angle += 90.0;
		std::swap(rect_size.width, rect_size.height);
	}
	// get the rotation matrix
	M = getRotationMatrix2D(rect.center, angle, 1.0);
	// perform the affine transformation
	cv::warpAffine(src, rotated, M, src.size(), CV_INTER_LANCZOS4);
	// crop the resulting image
	getRectSubPix(rotated, rect_size, rect.center, dst);
}


//
//int apply_transformations(Mat & original_img, string & path,
//		Size img_size, std::vector<std::pair<string, int> > &lines,
//		int index, int count)
//{
//	Mat img, enhanced_img;
//	original_img.copyTo(img);
//	string img_path;
//
//	namedWindow( "image", CV_WINDOW_NORMAL  );
//
//	imshow("image",img);waitKey(10);
//
//	//green channel-scale
//	vector<Mat> bgrMat;
//	split(img,bgrMat);
//	bgrMat[1].copyTo(img);
//	enhanceContrast(img,img);
//	img.copyTo(enhanced_img);
//	resize(img,img,img_size);
//	img_path = path +  std::to_string(count)+".png";
//	imwrite(img_path,img);
//	count++;
//	lines.push_back(std::make_pair(img_path, index));
//	//imshow("image",img);waitKey(10);
//
//
//	//scale without deformation
//	//padding with zeros
//	enhanced_img.copyTo(img);
//	scale_without_deformation(img,img,img_size);
//	img_path = path + std::to_string(count)+".png";
//	imwrite(img_path,img);
//	count++;
//	lines.push_back(std::make_pair(img_path, index));
//	//imshow("image",img);waitKey(10);
//	//
//
//
//
//	//prepare for tranformations
//	Mat src;
//	enhanced_img.copyTo(img);
//	scale_without_deformation(img,img,img_size);
//	img.copyTo(src);
//
//
//	//warp
//	vector<Mat> warp_mats;
//	vector<Mat> images;
//	images.push_back(img);
//	get_warp_matrices(warp_mats, img_size);
//
//	for (int i = 0 ; i< warp_mats.size() ; i++)
//	{
//		warpAffine( src, img, warp_mats[i], img.size(),INTER_LANCZOS4 );
//		images.push_back(img);
//	}
//
//	//rotate scale and mirror
//	Mat rot_mat( 2, 3, CV_32FC1 );
//
//	for (int k = 0 ; k< images.size(); k++)
//	{
//	 images[k].copyTo(src);
//	/// Compute a rotation matrix with respect to the center of the image
//	Point center = Point( img.cols/2, img.rows/2 );
//	double angle ;
//	double scale;
//
//	for ( angle = 0 ; angle <360 ; angle+=18)
//		for (scale = 0.8 ; scale <= 1.2 ; scale+=0.2)
//		{
//			/// Get the rotation matrix with the specifications above
//			rot_mat = getRotationMatrix2D( center, angle, scale );
//			/// Rotate the image
//			warpAffine( src, img, rot_mat, img.size(),INTER_LANCZOS4 );
//
//			img_path = path + std::to_string(count)+".png";
//			imwrite(img_path,img);
//			count++;
//			lines.push_back(std::make_pair(img_path, index));
//		//	imshow("image",img);waitKey(10);
//
//			flip (img,img,1);
//			img_path = path + std::to_string(count)+".png";
//			imwrite(img_path,img);
//			count++;
//			lines.push_back(std::make_pair(img_path, index));
//		//	imshow("image",img);waitKey(10);
//		//	cout<<"angle: "<<angle<<", scale: "<<scale<<endl;
//		}
//
//	}
//
//
//
//	return count;
//}



//

//from
//http://stackoverflow.com/questions/16702966/rotate-image-and-crop-out-black-borders
double degree_to_radian(double angle)
{
    return angle * CV_PI / 180;
}
cv::Size largest_rotated_rect(int h, int w, double angle)
{
    // Given a rectangle of size wxh that has been rotated by 'angle' (in
    // radians), computes the width and height of the largest possible
    // axis-aligned rectangle within the rotated rectangle.

    // Original JS code by 'Andri' and Magnus Hoff from Stack Overflow

    // Converted to Python by Aaron Snoswell (https://stackoverflow.com/questions/16702966/rotate-image-and-crop-out-black-borders)
    // Converted to C++ by Eliezer Bernart

    int quadrant = int(floor(angle/(CV_PI/2))) & 3;
    double sign_alpha = ((quadrant & 1) == 0) ? angle : CV_PI - angle;
    double alpha = fmod((fmod(sign_alpha, CV_PI) + CV_PI), CV_PI);

    double bb_w = w * cos(alpha) + h * sin(alpha);
    double bb_h = w * sin(alpha) + h * cos(alpha);

    double gamma = w < h ? atan2(bb_w, bb_w) : atan2(bb_h, bb_h);

    double delta = CV_PI - alpha - gamma;

    int length = w < h ? h : w;

    double d = length * cos(alpha);
    double a = d * sin(alpha) / sin(delta);
    double y = a * cos(gamma);
    double x = y * tan(gamma);

    return cv::Size(bb_w - 2 * x, bb_h - 2 * y);
}


cv::Mat crop_around_center(cv::Mat image, int height, int width)
{
    // Given a OpenCV 2 image, crops it to the given width and height,
    // around it's center point

    cv::Size image_size = cv::Size(image.rows, image.cols);
    cv::Point image_center = cv::Point(int(image_size.height * 0.5), int(image_size.width * 0.5));

    if (width > image_size.width)
        width = image_size.width;

    if (height > image_size.height)
        height = image_size.height;

    int x1 = int(image_center.x - width  * 0.5);
    int x2 = int(image_center.x + width  * 0.5);
    int y1 = int(image_center.y - height * 0.5);
    int y2 = int(image_center.y + height * 0.5);


    return image(cv::Rect(cv::Point(y1, x1), cv::Point(y2,x2)));
}
