/*
 * utility.cpp
 *
 *  Created on: Mar 11, 2015
 *      Author: nyalcinb
 */
#include "../include/utility.h"

std::vector <std::string> read_directory( const std::string& path )
{
	std::vector <std::string> result;
	string temp_string;
	dirent* de;
	DIR* dp;
	errno = 0;
	dp = opendir( path.empty() ? "." : path.c_str() );
	if (dp)
	{
		while (true)
		{
			errno = 0;
			de = readdir( dp );
			if (de == NULL) break;
			else{
				temp_string= std::string( de->d_name );
				if (temp_string== "." or temp_string == "..") continue;
				else
					result.push_back( temp_string );
			}
		}
		closedir( dp );
		std::sort( result.begin(), result.end() );

		cout<<"number of files: "<<result.size()<<endl;
	}
	return result;
}

void enhanceContrast(Mat &img, Mat &dst)
{
	Mat src;
	if (img.channels() ==1)
		cvtColor(img,src,CV_GRAY2BGR);
	else
		img.copyTo(src);
	IplImage img2= src;
	AARGB_MAIN((uchar *)img2.imageData,src.cols,src.rows,0,0,src.cols-1,src.rows-1,0,0,0);

	Mat tmp2(&img2);
	tmp2.copyTo(dst);

	if (img.channels()==1){
		cvtColor(dst,dst,CV_BGR2GRAY);
	}
}

//from
//https://github.com/ipa-rmb
///cob_people_perception/blob/indigo_dev/cob_people_detection/common/src/face_normalizer.cpp
void logDCT(Mat &img, Mat &dst)
{

	cv::Mat input_img;
	img.copyTo(input_img);

	if(input_img.channels()==3)
	{
		cvtColor(img,input_img, CV_BGR2GRAY);
	}

	// Dct conversion on logarithmic image
	if( input_img.rows&2!=0 )
	{
		input_img=input_img(cv::Rect(0,0,input_img.cols,input_img.rows-1));
	}
	if( input_img.cols&2!=0 )
	{
		input_img=input_img(cv::Rect(0,0,input_img.cols-1,input_img.rows));
	}
	cv::equalizeHist(input_img,input_img);
	input_img.convertTo(input_img,CV_32FC1);
	cv::Scalar mu,sigma;
	cv::meanStdDev(input_img,mu,sigma);
	double C_00=log(mu.val[0])*sqrt(input_img.cols*input_img.rows);
	//----------------------------
	// gamma correction
	cv::pow(input_img,0.2,input_img);
	cv::Mat imgdummy;
	input_img.convertTo(imgdummy,CV_8UC1);
	cv::dct(input_img,input_img);
	//---------------------------------------
	input_img.at<float>(0,0)=C_00;
	input_img.at<float>(0,1)/=10;
	input_img.at<float>(0,2)/=10;
	input_img.at<float>(1,0)/=10;
	input_img.at<float>(1,1)/=10;
	//--------------------------------------
	cv::idct(input_img,input_img);
	cv::normalize(input_img,input_img,0,255,cv::NORM_MINMAX);
	input_img.convertTo(input_img,CV_8UC1);

	if(img.channels()==3)
	{
		cvtColor(input_img, dst,CV_GRAY2BGR);
	}
	else
	{
		dst=input_img;
	}
}
