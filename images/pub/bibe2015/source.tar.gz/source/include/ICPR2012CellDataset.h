#pragma once
#include <opencv2/opencv.hpp>
#include <string>
#include <vector>
#include <sys/stat.h>

class ICPR2012 {

public:
	ICPR2012();
	std::string master_folder_str= "../MIVIA_HEp-2_Images_Dataset/";
	int num_of_images=28;
	std::vector<std::string> cell_class= {"homogeneous","coarse_speckled","fine_speckled","nucleolar","centromere","cytoplasmatic"};

	cv::Size final_size{cv::Size(64,64)};

	int img_idx_col = 3;
	int cell_idx_col = 5;
	int cell_class_col = 6 ;

	int train_set_value;
	int test_set_value;

	int maxX_col = 8;
	int maxY_col = 9;
	int minX_col = 6;
	int minY_col = 7;

	std::map< int, int>  cell_map;
	cv::Mat cell_csv_mat;
	std::vector<cv::Mat> img_csv_vec;


	void get_contest_cell_csv_mat(void);
	void get_image_csv_vector(void);
	void read_contest_cell_csv_file(cv::Mat &dst,std::map<std::string,int> &map);
	void read_csv_file_of_image(const int img_idx, cv::Mat &dst,std::map<std::string,int> &map);
	void read_image_mask_from_index(const int img_idx,cv::Mat &img, int channel_id, bool enhance, cv::Mat &mask);
	void  doit();
	void save_original_data();

	void normalizeGeometryPopColor();

};

void transform_and_add_data();
void add_ICPR2014();
void add_SNPHEP2();
void apply_transformations ();
void add_normalized_ICPR2014();
void add_normalized_SNPHEP2();

void crop_and_rotate();

