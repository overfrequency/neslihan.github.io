/*
 * utility
 *
 *  Created on: Mar 2, 2015
 *      Author: nyalcinb
 */
#ifndef UTILITY_
#define UTILITY_
#pragma once
#include <errno.h>
#include <cstring>
#include <map>
#include <string>
#include <vector>
#include <dirent.h>
#include <sys/types.h>
#include <stdio.h>

#include <opencv2/opencv.hpp>
#include "aargb.h"

using namespace std;
using namespace cv;

std::vector <std::string> read_directory( const std::string& path  );
void enhanceContrast(Mat &img, Mat &dst);

void logDCT(Mat &img, Mat &dst);

#endif /* UTILITY_ */
