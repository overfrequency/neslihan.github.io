﻿/*-----------------------------------------------------------------------
This file is part of aaphoto.

aaphoto is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

aaphoto is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
------------------------------------------------------------------------*/





/* --------------------------------------------------- */
/* ----------- Auto Adjust RGB ----------------------- */
/* ----------- András Horváth (C) 2006-2012 ---------- */
/* ----------- Hungary, http://log69.com ------------- */
/* --------------------------------------------------- */

/*

aaRGB Changelog:
------------------
2011/01/26 - aaRGB v0.64 - the contrast seemed strong with the default initial value of the former algorithm,
so now constant optimized to the new contrast algorithm introduced in 0.63
- add more detailed explanations to the contrast algorithm (in hungarian)
2010/12/18 - aaRGB v0.63 - include OpenMP defs in aargb.c too for standalone usage
- fix some warning messages during build
- make embedded test info image look more readable by changing the colors (--test switch)
- change saturation algorithm from linear to exponential
- improve contrast algorithm to include a self balance mechanism to avoid overexposure
on images with large blank areas that have relatively small details
- improve color balance algorithm to make it a bit more aggressive by raising the value
of the color difference factor of the white and black point to the 3rd power
- speed up process by skipping saturation part if no change is needed
- some memory allocation check
- some changes in documentation
2010/09/14 - aaRGB v0.62 - bugfix: an ugly misconception in my paralleled code caused weird behavior
when using more threads
- rewrite the code to suffice the ISO C90 ANSI standard C form (GCC -pedantic option)
2010/05/02 - aaRGB v0.61 - add OpenMP support for multi processing, all computing cycles paralleled
- solve warning issues with some uninitialized variables
- some code cleanup
2009/10/18 - aaRGB v0.60 - remove gamma handling of the lighter colors from the two-pole gamma computing
by setting the gamma_interval_high from 0.9 to 1, it proved to be inefficient
2009/04/05 - aaRGB v0.59 - some more code cleanup
2009/02/22 - aaRGB v0.58 - code cleanup
2007/08/11 - aaRGB v0.57 - improve black and white point analyzing
from now they are not scaled to perfect black and white, but to their darkest
and brightest color that have maximum saturation to fix overexposure problem
- improve saturation algorithm with full floating point computing and HSL conversion
to fix over saturated colors
- expand image information display with color balance circle for testing (--test switch)
- remove text information from test display (--test switch)
2007/06/21 - aaRGB v0.56 - expand functionality with "apply only on selection" to process only the selected area
2007/04/03 - aaRGB v0.55 - maximize saturation limit with a predefined constant to avoid overexposure in saturation
when reconverting the same image
2007/04/01 - aaRGB v0.54 - new two-pole gamma computing
- new saturation compensation
2007/03/29 - aaRGB v0.53 - improve contrast computing to avoid underexposure
2007/02/25 - aaRGB v0.52 - improve image information display for testing (--test switch)
2007/02/16 - aaRGB v0.51 - improve average RGB color computing for more accurate color balance calibration
2007/01/04 - aaRGB v0.49 - stable working version with gamma handling and more clever image analyzing
2006/08/29 - aaRGB project begun...

aaRGB end of Changelog.

*/


/* ---------------------------------------------------------------- */
/* -- Automatically adjusts contrast, color balance, gamma level -- */
/* -- and saturation of an RGB image ------------------------------ */
/* ---------------------------------------------------------------- */

/*
pictures might need some contrast adjustment when their colors don't spread
the entire spectrum, usually when their darkest colors aren't dark enough and
the lightest colors not bright enough, this causing a veiled effect on them.
sometime color balance adjustment is also necessary, when the brightest and darkest
colors of the image are not black and white enough, but they are shifted towards
some other color which may be the effect of the technology used,
or simply the environment changes the colors unrealistically.
the procedure assumes that there must be some detail on the picture that's
supposed to be black (dark enough) and also white (bright enough) in real.
the automatic contrast and color balance process is built upon this.
the overall (or average) brilliance of the image can be set by the gamma level.
this procedure makes sure that those pictures that seem too dark will be
corrected by this factor by changing the middle dark colors while not changing
the darkest and brightest colors.
as the last step, a saturation adjustment takes place to intensify the colors
themselves if needed.
*/


#pragma once

#include <math.h>
#include <stdlib.h>



/* ------------------------- */
/* ----- SIGN FUNCTION ----- */
/* ------------------------- */

int sgn(double x);



/* -------------------------------- */
/* ----- RGB - HSL CONVERSION ----- */
/* -------------------------------- */

void RGB_TO_HSL(double R, double G, double B, double *H1, double *S1, double *L1);



void HSL_TO_RGB(double H, double S, double L, double *R1, double *G1, double *B1);



/* ------------------------------------------------------------------------------ */

void AARGB_MAIN(
    unsigned char *image_buffer,
    int image_width,
    int image_height,
    int x1,
    int y1,
    int x2,
    int y2,
    int format_flag,
    int apply_on_selection,
    int test_flag);



/* ------------------------------ */
/* ----- MAIN AARGB ENTRIES ----- */
/* ------------------------------ */

void AARGB_NORMAL(
    unsigned char *image_buffer,
    int image_width,
    int image_height);

void AARGB_NORMAL_SEL(
    unsigned char *image_buffer,
    int image_width,
    int image_height,
    int x1,
    int y1,
    int x2,
    int y2,
    int apply_on_selection);

void AARGB_DIB(
    unsigned char *image_buffer,
    int image_width,
    int image_height);

void AARGB_DIB_SEL(
    unsigned char *image_buffer,
    int image_width,
    int image_height,
    int x1,
    int y1,
    int x2,
    int y2,
    int apply_on_selection);

void AARGB_BMP(
    unsigned char *image_buffer);

void AARGB_BMP_SEL(
    unsigned char *image_buffer,
    int x1,
    int y1,
    int x2,
    int y2,
    int apply_on_selection);

