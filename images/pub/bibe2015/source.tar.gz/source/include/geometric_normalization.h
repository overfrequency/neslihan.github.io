#pragma once
#include <opencv2/opencv.hpp>
#include <string>
#include "sIndex.h"

void fit_ellipse_to_mask (const cv::Mat &mask, cv::RotatedRect & ellipse);
void apply_rotation_to_patch (const cv::Mat &big_img, const cv::Rect & crop, const cv::Mat &mask, const bool rot, std::vector<cv::Mat> & transformed_mats );
void rotate(const cv::Mat& src, const  float angle,  const cv::Point2f center, cv::Mat& dst);
void extract_rotated_patch(const cv::Mat &src, const cv::RotatedRect &rect, cv::Mat &dst);
void apply_rotation_to_masked_patch (const cv::Mat &big_img, const cv::Rect &crop, const cv::Mat &mask, const bool rot_flag, const cv::Size sq_size, std::vector<cv::Mat> & transformed_mats );
void apply_rotation_to_patch2 (const cv::Mat &big_img, const cv::Rect &crop, const cv::Mat &mask, const bool rot_flag, std::vector<cv::Mat> & transformed_mats );
void rotate_without_crop(const cv::Mat& src, const  float angle, const cv::Point2f pt, cv::Mat& dst);
double degree_to_radian(double angle);
cv::Size largest_rotated_rect(int h, int w, double angle);
cv::Mat crop_around_center(cv::Mat image, int height, int width);
