%initialize matlab and folders

current_folder = pwd;
addpath(genpath(current_folder));
utilities;
algorithms;
save_envi;
disp('Initialization done!');

