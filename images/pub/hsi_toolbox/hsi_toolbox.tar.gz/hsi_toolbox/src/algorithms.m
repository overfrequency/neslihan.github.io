% Some functions are from
% https://github.com/isaacgerg/matlabHyperspectralToolbox

function algs = algorithms
  assignin('base','hyperconvert2d',@hyperconvert2d);
  assignin('base','hyperconvert3d',@hyperconvert3d);
  assignin('base','hypercov',@hypercov);
  assignin('base','viewcov',@viewcov);
  assignin('base','hyperpca',@hyperpca);
  assignin('base','viewpc',@viewpc);
 assignin('base','hyperregister',@hyperregister);
  assignin('base','hyperregistercorr',@hyperregistercorr);
  
  algs='Done importing algorithmic functions to workspace';
end



function M= hyperconvert2d(hs)
% Converts a 3D HSI cube (m x n x p) to a 2D matrix of points (p X N)
% where N = mn
if (ndims(hs)>3 || ndims(hs)<2)
    error('Input image must be m x n x p or m x n');
end
if (ndims(hs) == 2)
    numBands = 1;
    [h, w] = size(hs);
else
    [h, w, numBands] = size(hs);
end

M = reshape(hs, w*h, numBands).';

end



function C = hypercov(hs)
% hypercov compute the sample covariance matrix of a 2D matrix.

[p, N] = size(hs);
% Remove mean from data
u = mean(hs.').';
for k=1:N
    M(:,k) = hs(:,k) - u;
end

C = (M*M.')/(N-1);

end


function viewcov(hs)

    c= hypercov(hyperconvert2d(hs));
    sFig =figure(1);
    set(sFig, 'Position', [100 600 400 400]);
    imshow(c, 'DisplayRange',[min(c(:)) max(c(:))],'Colormap',gray )
end



function [M_pct, V, lambda] = hyperpca(M)
%HYPERPCA Performs the principal components transform (PCT)
%   hyperPct performs the principal components transform on a data matrix.
%
% Usage
%   [M_pct, V] = hyperPct(M, q)
% Inputs
%   M - 2D  matrix (p x N)
% Outputs
%   M_pct - 2D matrix (q x N) which is result of transform
%   V - Transformation matrix.
%   lambda - eigenvalues
%
% References
%   http://en.wikipedia.org/wiki/Principal_component_analysis

[p, N] = size(M);

% Remove the data mean
u = mean(M.').';
%M = M - repmat(u, 1, N);
M = M - (u*ones(1,N));

% Compute covariance matrix
C = (M*M.')/N;

% Find eigenvalues of covariance matrix
% if q < p
%     [V, D] = eigs(C, q);
% elseif q > p
%     error('Number of principal components should be smaller (max = number of bands)');
% else
    [V, D] = svd(C);
% end
    
% Transform data
M_pct = V'*M;

lambda = diag(D);

end


function [img] = hyperconvert3d(img, h, w, numBands)
% Converts a 2D matrix (p x N) to a 3D data cube (m x n x p)
% where N = m * n
% 
% Usage
%   [M] = hyperConvert3d(M)
% Inputs
%   M - 2D data matrix (p x N)
% Outputs
%   M - 3D data cube (m x n x p)


if (ndims(img) ~= 2)
    error('Input image must be p x N.');
end

[numBands, N] = size(img);

if (1 == N)
    img = reshape(img, h, w);
else
    img = reshape(img.', h, w, numBands); 
end

end


function viewpc(hs ,numpc, color)
    if ~exist('color', 'var') ||  isempty(color)
        color = hsv;
    end


m = hyperconvert2d(hs);
[mpct , v, lambda] = hyperpca(m);
img = hyperconvert3d(mpct,size(hs,1), size(hs,2), numpc);

%calculate total variance contained in pc
sp = (lambda).*(lambda);
tv = (sum(sp(1:numpc)))/sum(sp)*100.0;

fprintf('Total variance contained in %d  principal components is %2.5f%%\n',numpc,tv);


uiwait (msgbox({'Principal components (pcs) will be displayed sequentially. '...
    'In order to see the next component close the current window. '}));


for i=1:numpc
    
    wname = strcat('Principal component : ', int2str(i));
    msg = [wname ' is displayed now. Close the current figure to see next component!'];
    disp(msg);
    
    tvi = sp(i)/sum(sp)*100.0;
    fprintf('Total variance contained in principal component %d is %2.5f%%\n',i,tvi);
    
    hFig = figure('NumberTitle','off');
    set(hFig,'Name',wname);
    pc = img(:,:,i);
	imshow(pc, 'DisplayRange',[min(pc(:)) max(pc(:))],'Colormap',color );
    colorbar;
%     [cdata, color] = getframe(hFig);
%       
%     if save=='true'
%         fname = strcat('output', filesep, 'pc', string(i), '.png')
%         imwrite(cdata, color , fname)
%     end
%     
    waitfor(hFig);

end


end




function reg=hyperregister(hs)
warning('off','all');
% register bands 

%normalize data
minVal = min(hs(:));
maxVal = max(hs(:));

reg = hs - minVal;
if (maxVal == minVal)
    reg = zeros(size(hs));
else
    reg = reg ./ (maxVal-minVal);
end

w = 400;
h= 400;
%select 400x400 subregion from cube
rows = size(hs,1);
cols =size(hs, 2);
nbands = size(hs,3);


if rows < h
    r1 = 1; r2 = rows;
else
    rmargin = (rows-h)*0.5;
    r1 = rmargin;
    r2 = r1+h-1 ;
end
if cols < w
    c1 = 1 ; c2 = cols
else
    cmargin = (cols-w)*0.5;
    c1 = cmargin;
    c2 = c1+h-1 ;
end
    


[optimizer, metric] = imregconfig('monomodal');

    %hFig = figure(1);
reverseStr = '';
for i = 2:nbands

   %%%%%%%%Display the progress
   percentDone = 100 * i / nbands;
   msg = sprintf('Percent done: %3.1f', percentDone); %Don't forget this semicolon
   fprintf([reverseStr, msg]);
   reverseStr = repmat(sprintf('\b'), 1, length(msg));
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    moving = reg(r1:r2 , c1:c2 , i);
    fixed =  reg(r1:r2 , c1:c2 , i-1);
    tform = imregtform(moving, fixed, 'translation', optimizer, metric);
    
    rmoving = reg(:,:, i);
    rfixed = reg(:,: , i-1);
    
    movingRegistered = imwarp(rmoving,tform,'FillValues',0,'OutputView',imref2d(size(rfixed)));
    
%     moving = hs(:,:, i);
%     movingRegistered = imregister(moving, fixed, 'affine', optimizer, metric);
    
    reg(:,:,i) = movingRegistered;
    
    

end

warning('on','all')
disp(' ' );

end


function reg=hyperregistercorr(hs)
warning('off','all');
% register bands 

%normalize data
minVal = min(hs(:));
maxVal = max(hs(:));

reg = hs - minVal;
if (maxVal == minVal)
    reg = zeros(size(hs));
else
    reg = reg ./ (maxVal-minVal);
end


%select a window
w = 300;
h= 300;
%select 400x400 subregion from cube
rows = size(hs,1);
cols =size(hs, 2);
nbands = size(hs,3);


if rows < h
    r1 = 1; r2 = rows;
else
    rmargin = (rows-h)*0.5;
    r1 = rmargin;
    r2 = r1+h-1 ;
end
if cols < w
    c1 = 1 ; c2 = cols;
else
    cmargin = (cols-w)*0.5;
    c1 = cmargin;
    c2 = c1+h-1 ;
end
    


[optimizer, metric] = imregconfig('monomodal');

reverseStr = '';
for i = 2:nbands

   %%%%%%%%Display the progress
   percentDone = 100 * i / nbands;
   msg = sprintf('Percent done: %3.1f', percentDone); %Don't forget this semicolon
   fprintf([reverseStr, msg]);
   reverseStr = repmat(sprintf('\b'), 1, length(msg));
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    moving = reg(r1:r2 , c1:c2 , i);
    fixed =  reg(r1:r2 , c1:c2 , i-1);
    tform = imregcorr(moving,fixed);
    
    movingReg = imwarp(moving,tform,'OutputView',imref2d(size(fixed)));
    %imshowpair(fixed,movingReg,'falsecolor');
    
    rmoving = reg(:,:, i);
    rfixed = reg(:,: , i-1);
    
    %movingRegistered = imregister(rmoving, rfixed,...
    %'affine', optimizer, metric,'InitialTransformation',tform);
    
    movingRegistered = imwarp(rmoving,tform,'FillValues',0,'OutputView',imref2d(size(rfixed)));
    
    reg(:,:,i) = movingRegistered;
    
    
end

warning('on','all')
disp(' ' );

end