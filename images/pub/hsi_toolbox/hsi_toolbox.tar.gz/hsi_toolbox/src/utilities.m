function funs = utilities
  assignin('base','hsinfo',@hsinfo);
  assignin('base','loadenvi',@loadenvi);
assignin('base','displayband',@displayband);
  assignin('base','loadreference',@loadreference);
  assignin('base','normalizecube',@normalizecube);
  assignin('base','normalizecubefilenames',@normalizecubefilenames);
  assignin('base','write2tiff',@write2tiff);
  assignin('base','write2tiff_fromfiles',@write2tiff_fromfiles);
  assignin('base','hypernormalize',@hypernormalize);
  assignin('base','plotpointspectra',@plotpointspectra);
  assignin('base','displaymean',@displaymean);
  assignin('base','subvolume',@subvolume);
  assignin('base','displaymaxband',@displaymaxband);
  assignin('base','meanmaxbandroi',@meanmaxbandroi);
  funs='Done importing functions to workspace';
end


%%
function inf= hsinfo(filename)
[pathstr,name,ext] = fileparts(filename);


if (exist(strcat(pathstr,filesep, name,'.hdr'), 'file') == 0)
    disp(strcat(pathstr,filesep, name,'.hdr'))
    error('File does not exits! check the file name and path');
    
else
    inf =read_envihdr(strcat(pathstr,filesep, name,'.hdr'));
end

end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%this function reads envi header and
%loads hyperpectral data into 3 dimensional matrix 
function cube = loadenvi(filename)
%check filename

[pathstr,name,ext] = fileparts(filename); 

if (exist(strcat(pathstr,filesep, name,'.hdr'), 'file') == 0)
    disp(strcat(pathstr,filesep, name,'.hdr'))
    error('File does not exits! check the file name and path');
    
else
    info =read_envihdr(strcat(pathstr,filesep, name,'.hdr'));
    cube = multibandread(strcat(pathstr,filesep, name,'.dat'), info.size, [info.format '=>double'], ...
    info.header_offset, info.interleave, info.machine);
end


end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
function displayband(cube, band_index, color)
    if ~exist('color', 'var') ||  isempty(color)
        color = gray;
    end
colormap(color);
%image(cube(:,:,band_index));
img = cube(:,:,band_index);
imshow(img, 'DisplayRange',[min(img(:)) max(img(:))],'Colormap',color )
colorbar;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function displaymean(cube, first, last, color)
% 
%     if ~exist('first', 'var') ||  isempty(first)
%         first = 1;
%     end
%     
%     if ~exist('last', 'var') ||  isempty(last)
%         last = size(cube,3);
%     end
%     
%     if ~exist('cl', 'var') ||  isempty(color)
%         color = gray;
%     end
% colormap(cl);
% %image(cube(:,:,band_index));
% newcube = cube(:,:,first:last);
% img = mean(newcube,3);
% imshow(img, 'DisplayRange',[min(img(:)) max(img(:))],'Colormap',color )
% colorbar;
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
function displaymean(cube, varargin)

first = 1;
last = size(cube,3);
color = gray;

 while ~isempty(varargin)
    switch lower(varargin{1})

          case 'first'
              first = varargin{2};

          case 'last'
              last = varargin{2};

        case 'color'
              color = varargin{2};
     end

      varargin(1:2) = [];
  end


colormap(color);
%image(cube(:,:,band_index));
newcube = cube(:,:,first:last);
img = mean(newcube,3);
imshow(img, 'DisplayRange',[min(img(:)) max(img(:))],'Colormap',color )
colorbar;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
function reference=loadreference(filename)
%this function reads envi header and
%loads hyperpectral data into 3 dimensional matrix 
[pathstr,name,ext] = fileparts(filename); 

if (exist(strcat(pathstr,filesep, name,'.hdr'), 'file') == 0)
    disp(strcat(pathstr,filesep, name,'.hdr'))
    error('File does not exits! check the file name and path');
    
else
    info =read_envihdr(strcat(pathstr,filesep, name,'.hdr'));
    reference = multibandread(strcat(pathstr,filesep, name,'.dat'), info.size, [info.format '=>double'], ...
    info.header_offset, info.interleave, info.machine);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
function normalized = normalizecube (data, reference)
normalized = data./reference;
end

%%
function normalized = normalizecubefilenames (datafile, referencefile)
data = loadreference(datafile);
reference = loadreference(referencefile);
normalized = data./reference;
clear data
clear reference
end

%%
function write2tiff(hs, filename)
%write multidimensional matlab matrix as tiff stacks
%data is normalzied and transformed to uint16 before saving!
currLoc = pwd;
outputFileName = fullfile(currLoc,'output',filename) %strcat('output',filesep, filename);
hs = hypernormalize(hs)*255;

  for K=1:length(hs(1, 1, :))
     im = uint16(hs(:, :, K));
     imwrite(im, outputFileName, 'WriteMode', 'append','Compression','none');
  end
  fclose all;

% 
% timg = single(hs);
% t = Tiff(filename, 'w'); 
% tagstruct.ImageLength = size(timg, 1); 
% tagstruct.ImageWidth = size(timg, 2); 
% tagstruct.Compression = Tiff.Compression.None; 
% tagstruct.SampleFormat = Tiff.SampleFormat.IEEEFP; 
% tagstruct.Photometric = Tiff.Photometric.MinIsBlack; 
% tagstruct.BitsPerSample = 32; 
% tagstruct.SamplesPerPixel = size(timg, 3); 
% tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky; 
% t.setTag(tagstruct); 
% t.write(timg); 
% t.close();

end

%%
function write2tiff_fromfiles(datafile, filename)
%write multidimensional matlab matrix as tiff stacks
% data is normalzied and transformed to uint16 before saving!

hs = loadreference(datafile);
currLoc = pwd;
outputFileName = fullfile(currLoc,'output',filename) %strcat('output',filesep, filename);
%outputFileName = fullfile('output', filename);%strcat('output',filesep, filename);
hs = hypernormalize(hs)*255;

  for K=1:length(hs(1, 1, :))
     im = uint16(hs(:, :, K));
     imwrite(im, outputFileName, 'WriteMode', 'append','Compression','none');
  end
clear hs;
fclose all;
end

%%
function normalizedM = hypernormalize( M )
% hyperNormalize Normalizes data to be in range [0, 1]

minVal = min(M(:));
maxVal = max(M(:));

normalizedM = M - minVal;
if (maxVal == minVal)
    normalizedM = zeros(size(M));
else
    normalizedM = normalizedM ./ (maxVal-minVal);
end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
function plotpointspectra(hs)
% input: matlab matrix
uiwait (msgbox({'You will see two figures after you close this window.' 
    'The first figure shows the first wavelength.' 
    'Double click to a location on this image to see its point spectra.'
    'Second figure shows spectra after you click. '
     'Press q to quit. '}));


img= hs(:,:,1);

finish=false;
count =1;
%cl = colorcube;
cl = get(gca, 'ColorOrder');

sFig = figure(2);
%set(sFig,'defaultAxesColorOrder',cl)
set(sFig, 'Position', [100 600 1000 500]);
xlabel('Band number')
ylabel('Spectrum')
%hold on

imFig=figure(1);
%set(imFig,'defaultAxesColorOrder',cl)
imshow(img, 'DisplayRange',[min(img(:)) max(img(:))],'Colormap',gray );
hold on

%write to a file====================
currLoc= pwd;
filename= fullfile(currLoc,'output','pointspectra.txt')
fileID = fopen(filename,'w');%fopen(strcat('output', filesep,'pointspectra.txt'),'w');
fprintf(fileID,'%s %s ','x','y');
for k=1:size(hs,3)
    fprintf(fileID,'%s ', strcat('Band',num2str(k)));
end
fprintf(fileID,'\n');
%=====================================

while ~finish
 
  [x, y] = getpts;
  
  if x<=0 || x > size(img,2)
      disp('x is out of border')
  elseif y<= 0 || y > size(img,1)
      disp('x is out of border')
  else
    xc = x;
    yc = y;
    
    
    
    fprintf('Clicked point coordinates are x= %d  and y= %d\n',floor(xc),floor(yc));
    
    figure(1);
    plot(xc,yc,'o', 'MarkerFaceColor', cl(count,:) );
    
    figure(2);
    hold on
    spec = hs(int16(yc),int16(xc),:);
    spec = spec(:);
    
    %write to a file=======================
    fprintf(fileID,'%d %d ',floor(xc),floor(yc));
    fline = spec';
    for k=1:size(fline,2)
        fprintf(fileID,'%f ',fline(k));
    end
    fprintf(fileID,'\n');  
    %===================================
    
    
    plot(spec,'-o', 'MarkerSize',2,'MarkerFaceColor', cl(count,:) );

    figure(1);
    hold on
    count = mod((count+1), size(cl,1));
    if count == 0 count =7; end
    
        
    disp( 'Press q to quit')
    w = waitforbuttonpress;
    if (w ==1)
        if strcmp(get(gcf,'CurrentCharacter'),'q')
            finish =true;
        end
    end
  end
        
end

close all;
end




%%
function subhs= subvolume(hs, varargin)

    y1 =1 ; y2 = size(hs,1) ;  x1= 1 ;  x2= size(hs,2) ; z1 =1 ; z2 = size(hs,3) ;
    
    for i=1:length(varargin)
       switch varargin{i}
       case 'x1'
         x1 = varargin{i+1};
         if (x1 <=0) || (x1>size(hs,2))
             error('x1 index is out of borders');
         end
             
       case 'x2'
         x2 = varargin{i+1};
         if (x2 <=0) || (x2>size(hs,2)) || (x2 < x1)
             error('x2 index is out of borders or smaller than x1');
         end
       case 'y1'
         y1 = varargin{i+1};
          if (y1 <=0) || (y1>size(hs,1))
             error('y1 index is out of borders');
         end
       case 'y2'
         y2 = varargin{i+1};
          if (y2 <=0) || (y2>size(hs,1)) || (y2 < y1)
             error('y2 index is out of borders or smaller than y1');
         end
       case 'z1'
         z1 = varargin{i+1};
         if (z1 <=0) || (z1>size(hs,3))
             error('z1 index is out of borders');
         end
       case 'z2'
           z2 = varargin{i+1};
          if (z2 <=0) || (z2>size(hs,3)) || (z2 < z1)
             error('z2 index is out of borders or smaller than z1');
         end
       end
    end 
    

    subhs = hs (y1:y2,x1:x2,z1:z2);

end

%%
function displaymaxband(hs, info,color)
    if ~exist('color', 'var') ||  isempty(color)
        color = gray;
    end
colormap(color);
%image(cube(:,:,band_index));
[im,ind]=max(hs,[],3);

wl = info.wavelength;
wl = cell2mat(wl);
nind=wl(ind);



img = nind;
imshow(img, 'DisplayRange',[min(img(:)) max(img(:))],'Colormap',color )
colorbar;
end


%%
%select a region and within that region calculate the mean wavelenght 
%that corresponds to the maximum intesity value
function meanmaxbandroi(hs, info,varargin)

colormap1 = gray;
colormap2 = gray;
colormap3 = gray;

 while ~isempty(varargin)
    switch lower(varargin{1})

          case 'colormap1'
              colormap1 = varargin{2};

          case 'colormap2'
              colormap2 = varargin{2};

        case 'colormap3'
              colormap3 = varargin{2};
     end

      varargin(1:2) = [];
  end

uiwait (msgbox({'Next image is going to show the first wavelegth of the hypercube'
    'Use mouse to select a region.' 
    'Then double click to finalize your selection.'
    'You will see mask of the region and the mean values.'
    'Close windows when you finished. '}));


%image(cube(:,:,band_index));
[im,ind]=max(hs,[],3);

wl = info.wavelength;
wl = cell2mat(wl);
nind=wl(ind);

img= hs(:,:,1);
figure('Name','First wavelength'),imshow(img, 'DisplayRange',[min(img(:)) max(img(:))],'Colormap',colormap1 )
colorbar;
h = imfreehand(gca);



totMask = false( size(img) ); % accumulate all single object masks to this one
position = wait( h );
bw = createMask( h );
figure('Name','Mask of the selected region'),
imshow(bw)


meanwavelength = mean(mean(nind(bw==1)));
nind(bw==1)=meanwavelength;
img=nind;
figure('Name','Wavelenght corresponding to max intensity'),imshow(img, 'DisplayRange',[min(img(:)) max(img(:))],'Colormap',colormap2 )
colorbar;


% bckwavelength = mean(mean(nind(bw==0)));
% nind(bw==0)=bckwavelength;
% img=nind;
% figure('Name','Mean wavelenght corresponding to max intensity'),imshow(img, 'DisplayRange',[min(img(:)) max(img(:))],'Colormap',colormap3 )
% colorbar;

fprintf('The mean wavelength that corresponds to the maximum intensity value of the selected region is  %3.1f %s \n', meanwavelength,info.wavelength_units );

end
%%

